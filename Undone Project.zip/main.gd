extends Node3D
var original = preload("res://Mob.tscn")

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$Timer.start() # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_timer_timeout() -> void:
	print("enemy created")
	var clone = original.instantiate()
	clone.player_Look($Player.position)
	add_child(clone) # Replace with function body.
