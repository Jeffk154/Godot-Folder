extends CharacterBody3D





func _physics_process(delta: float) -> void:
	var direction = Vector3(0 , 0 , 0)
	if Input.is_action_pressed("front"):
		direction.z = -1
	if Input.is_action_pressed("back"):
		direction.z = 1
	if Input.is_action_pressed("left"):
		direction.x = -1
	if Input.is_action_pressed("right"):
		direction.x = 1
	velocity = direction
	if direction != Vector3(0,0,0):
		look_at(global_position + direction.normalized() , Vector3(0 , 1 , 0))
	move_and_slide()
	
