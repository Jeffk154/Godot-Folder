extends CharacterBody3D





func _physics_process(delta: float) -> void:
	position = Vector3(-1,0.2,-1)
	#move_and_slide()
	
func player_Look(playerpos):
	#look_at_from_position(position,playerpos,Vector3(0,1,0))
	#velocity = Vector3(0,0,1)
	#velocity = velocity.rotated(Vector3(0,1,0),rotation.y)
	position = Vector3(-1,0.2,-1)
	
